/**
 * ============================================================================
 * FINANCEIRO.TSX
 * ============================================================================
 *
 * O QUE ESTE ARQUIVO FAZ?
 * ------------------------
 * Componente visual do frontend para financeiro.
 *
 * ONDE É USADO?
 * -------------
 * Usado na interface React como parte do frontend.
 *
 * COMO FUNCIONA?
 * --------------
 * Controla a apresentação e interações da interface com o usuário.
 */


import React, { useState, useMemo } from 'react';
import { Relatorios } from './Relatorios';
import { ConciliacaoBancaria } from './ConciliacaoBancaria';
import { ContasBancarias } from './ContasBancarias';
import { Tesouraria } from './Tesouraria';
import { 
  Plus, ArrowUp, ArrowDown, Download, FileText, CreditCard,
  Landmark, Wallet, TrendingUp, X, Save, DollarSign, Calendar, 
  Search, Filter, RefreshCw, Edit2, Trash2, ShieldCheck, 
  Receipt, User, Printer, Loader2, FileSearch, PieChart,
  Link as LinkIcon, Paperclip, CheckCircle2, AlertCircle, Layers,
  Briefcase, History, CheckCircle, Tag, MoreHorizontal
} from 'lucide-react';
import { Transacao, FinancialAccount, Usuario, Membro } from '../types';
import { COST_CENTERS, OPERATION_NATURES, CHURCH_PROJECTS } from '../constants';
import { dbService } from '../services/databaseService';
import { useAudit } from '../src/hooks/useAudit';
import AuthService from '../src/services/authService';

interface FinanceiroProps {
  transactions: Transacao[];
  currentIdUnidade: string;
  setTransactions: React.Dispatch<React.SetStateAction<Transacao[]>>;
  accounts: FinancialAccount[];
  setAccounts: React.Dispatch<React.SetStateAction<FinancialAccount[]>>;
  user?: Usuario;
  members: Membro[];
}

/**
 * BLOCO PRINCIPAL
 * ===============
 *
 * Define o bloco principal deste arquivo (financeiro).
 */

export const Financeiro: React.FC<FinanceiroProps> = ({ transactions, currentIdUnidade, setTransactions, accounts, setAccounts, user, members }) => {
  const canWriteFinance = AuthService.hasPermission(user as any, 'finance', 'write');
  const [activeTab, setActiveTab] = useState<'tesouraria' | 'conciliacao' | 'contas'>('tesouraria');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  // Hook de auditoria
  const { logAction } = useAudit(user);

  const [formData, setFormData] = useState<Partial<Transacao>>({
    descricao: '', 
    valor: 0, 
    data_transacao: new Date().toISOString().split('T')[0], 
    tipo: 'ENTRADA', 
    categoria: 'Dizimo', 
    natureza_operacao: 'nat6', 
    id_centro_custo: 'cc1', 
    id_projeto: '', 
    id_conta: accounts[0]?.id || accounts[0]?.id_conta || '', 
    situacao: 'REALIZADO', 
    id_unidade: currentIdUnidade, 
    forma_pagamento: 'PIX', 
    id_membro: '',
    parcelado: false,
    total_parcelas: 1,
    numero_parcela: undefined,
    id_transacao_origem: undefined,
  });

  const totals = useMemo(() => transactions.reduce((acc, curr) => {
    if (curr.situacao === 'REALIZADO') {
      if (curr.tipo === 'ENTRADA') acc.income += curr.valor || 0;
      else acc.expense += curr.valor || 0;
    } else if (curr.situacao === 'PENDENTE') acc.payable += curr.valor || 0;
    return acc;
  }, { income: 0, expense: 0, payable: 0 }), [transactions]);

  const filtered = transactions.filter(t =>
    (t.descricao || '').toLowerCase().includes(searchTerm.toLowerCase())
  ).sort((a, b) => new Date(a.data_transacao || '').getTime() - new Date(b.data_transacao || '').getTime());

  const handleSave = async () => {
    if (!canWriteFinance) {
      alert('Você não tem permissão para criar ou editar lançamentos financeiros.');
      return;
    }

    console.log("🚀 Iniciando salvamento da transação financeira...");
    
    if (!formData.descricao) {
      console.log("❌ Descrição obrigatória não preenchida");
      return alert("A descrição é obrigatória.");
    }

    setIsSaving(true);

    let finalDescription = formData.descricao;
    if (formData.categoria === 'Dizimo' && formData.id_membro) {
      const member = members.find(m => (m.id_membro === formData.id_membro));
      if (member && (!finalDescription || finalDescription === 'Dízimo')) {
        finalDescription = `Dízimo: ${member.nome}`;
      }
    }

    try {
      if (formData.parcelado && formData.total_parcelas && formData.total_parcelas > 1) {
        await gerarParcelas(formData);

        if (editingId) {
          await logAction('UPDATE', 'Transaction', editingId, finalDescription, {
            action: `${user?.nome || 'Usuário'} alterou a transação parcelada: ${finalDescription}`,
            tipo: 'INSTALLMENT_TRANSACTION',
            total_parcelas: formData.total_parcelas,
            valor: formData.valor
          });
        } else {
          await logAction('CREATE', 'Transaction', formData.id_transacao, finalDescription, {
            action: `${user?.nome || 'Usuário'} registrou nova transação parcelada: ${finalDescription}`,
            tipo: 'INSTALLMENT_TRANSACTION',
            total_parcelas: formData.total_parcelas,
            valor: formData.valor
          });
        }

        setIsModalOpen(false);
        setEditingId(null);
        setIsSaving(false);
        return;
      }

      const transactionData = {
        ...formData,
        descricao: finalDescription,
        id_transacao: editingId || `T${Date.now()}`,
        id_unidade: currentIdUnidade
      } as Transacao;

      console.log("📋 Dados da transação preparados:", {
        id_transacao: transactionData.id_transacao,
        descricao: transactionData.descricao,
        valor: transactionData.valor,
        tipo: transactionData.tipo
      });

      // Salvar no IndexedDB através do databaseService
      const savedId = await dbService.saveTransaction(transactionData);

      if (editingId) {
        await logAction('UPDATE', 'Transaction', editingId, finalDescription, {
          action: `${user?.nome || 'Usuário'} alterou a transação: ${finalDescription}`,
          tipo: 'SINGLE_TRANSACTION',
          valor: transactionData.valor,
          categoria: transactionData.categoria
        });
      } else {
        await logAction('CREATE', 'Transaction', savedId, finalDescription, {
          action: `${user?.nome || 'Usuário'} registrou nova transação: ${finalDescription}`,
          tipo: 'SINGLE_TRANSACTION',
          valor: transactionData.valor,
          categoria: transactionData.categoria
        });
      }

      // Atualizar o estado local
      if (editingId) {
        setTransactions(prev => prev.map(t => t.id_transacao === editingId ? { ...transactionData, id_transacao: savedId } : t));
        console.log("✅ Transação atualizada na lista global");
      } else {
        setTransactions(prev => [{ ...transactionData, id_transacao: savedId }, ...prev]);
        console.log("✅ Nova transação adicionada à lista global");
      }

      setIsModalOpen(false); 
      setEditingId(null);
      console.log("🎉 Processo de salvamento finalizado com sucesso!");
      alert("Transação salva com sucesso!");
      
    } catch (error) {
      console.error("❌ Erro ao salvar transação:", error);
      alert("Erro ao salvar transação. Tente novamente.");
    } finally {
      setIsSaving(false);
    }
  };

  const openModal = (t?: Transacao) => {
    if (!canWriteFinance) {
      alert('Você não tem permissão para editar lançamentos financeiros.');
      return;
    }

    // Normaliza data ISO para yyyy-MM-dd (formato exigido pelo input type="date")
    const toDateStr = (val?: string | null) => {
      if (!val) return new Date().toISOString().split('T')[0];
      if (/^\d{4}-\d{2}-\d{2}$/.test(val)) return val;
      return new Date(val).toISOString().split('T')[0];
    };

    if (t) {
      setEditingId(t.id_transacao);
      setFormData({ ...t, data_transacao: toDateStr(t.data_transacao) });
    } else {
      setEditingId(null);
      setFormData({
        descricao: '', 
        valor: 0, 
        data_transacao: new Date().toISOString().split('T')[0],
        tipo: 'ENTRADA', 
        categoria: 'Dizimo', 
        natureza_operacao: 'nat6', 
        id_centro_custo: 'cc1',
        id_projeto: '', 
        id_conta: accounts[0]?.id || accounts[0]?.id_conta || '', 
        situacao: 'REALIZADO',
        id_unidade: currentIdUnidade, 
        forma_pagamento: 'PIX', 
        id_membro: '',
        parcelado: false,
        total_parcelas: 1,
      });
    }
    setIsModalOpen(true);
  };

  /**
   * GERAR PARCELAS DE UMA COMPRA
   * ----------------------------
   * Cria automaticamente N transações (uma para cada parcela)
   * e registra em Contas a Pagar
   */
  const gerarParcelas = async (transactionData: Partial<Transacao>) => {
    console.log("🚀 Iniciando geração de parcelas...");
    
    const numeroParcelas = transactionData.total_parcelas || 1;
    const valorTotal = transactionData.valor || 0;
    const taxa = (transactionData as any).jurosPercentual || 0;
    const dataBase = new Date(transactionData.data_transacao || new Date());
    const parcelas: Transacao[] = [];

    // Calcular valor da parcela (com ou sem juros — fórmula Price)
    let valorParcela: number;
    if (taxa > 0) {
      const i = taxa / 100;
      valorParcela = valorTotal * i / (1 - Math.pow(1 + i, -numeroParcelas));
    } else {
      valorParcela = valorTotal / numeroParcelas;
    }
    
    try {
      for (let i = 1; i <= numeroParcelas; i++) {
        const vencimentoParcela = new Date(dataBase);
        vencimentoParcela.setMonth(vencimentoParcela.getMonth() + (i - 1));
        
        // Última parcela ajusta centavos (só sem juros)
        const amountParcela = taxa > 0
          ? parseFloat(valorParcela.toFixed(2))
          : (i === numeroParcelas ? valorTotal - (parseFloat(valorParcela.toFixed(2)) * (numeroParcelas - 1)) : parseFloat(valorParcela.toFixed(2)));

        const parcela: Transacao = {
          ...transactionData,
          id_transacao: `tmp-${Date.now()}-${i}`,
          descricao: `${transactionData.descricao} (${i}/${numeroParcelas})`,
          valor: amountParcela,
          data_transacao: vencimentoParcela.toISOString().split('T')[0],
          situacao: 'PENDENTE',
          tipo: transactionData.tipo || 'SAIDA',
          categoria: transactionData.categoria || 'OUTROS',
          id_centro_custo: transactionData.id_centro_custo || 'cc1',
          id_conta: transactionData.id_conta || accounts[0]?.id || accounts[0]?.id_conta || null,
          natureza_operacao: transactionData.natureza_operacao || 'nat6',
          parcelado: true,
          numero_parcela: i,
          total_parcelas: numeroParcelas,
          id_transacao_origem: undefined,
          data_criacao: new Date().toISOString(),
          id_unidade: currentIdUnidade,
        } as Transacao;
        
        if (i > 1) parcela.id_transacao_origem = parcelas[0].id_transacao;
        
        console.log(`💾 Salvando parcela ${i}/${numeroParcelas} — R$ ${amountParcela.toFixed(2)}...`);
        const savedId = await dbService.saveTransaction(parcela);
        parcela.id_transacao = savedId;
        parcelas.push(parcela);
      }
      
      setTransactions([...parcelas, ...transactions]);
      
      const totalComJuros = valorParcela * numeroParcelas;
      const msg = taxa > 0
        ? `${numeroParcelas} parcelas geradas!\nValor: R$ ${valorParcela.toFixed(2)}/mês\nTotal com juros: R$ ${totalComJuros.toFixed(2)}\nJuros: R$ ${(totalComJuros - valorTotal).toFixed(2)}`
        : `${numeroParcelas} parcelas geradas!\nValor: R$ ${valorParcela.toFixed(2)}/mês\nTotal: R$ ${valorTotal.toFixed(2)}`;
      alert(msg);
      
    } catch (error: any) {
      console.error("❌ Erro ao gerar parcelas:", error);
      alert("Falha ao gerar parcelas. " + (error.message || "Verifique o console para mais detalhes."));
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in pb-16">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-lg font-black text-slate-900 uppercase tracking-tight leading-none italic font-serif">Tesouraria & ERP Cloud</h1>
          <p className="text-slate-400 font-medium text-[10px] uppercase tracking-tighter mt-1">Gestão de Naturezas e Centros de Custo ADJPA v5.0</p>
        </div>
        <div className="flex gap-2">
          {activeTab === 'tesouraria' && (
            <>
              <button onClick={() => setIsReportModalOpen(true)} className="px-4 py-1.5 bg-slate-200 text-slate-600 rounded-lg font-bold text-[10px] uppercase hover:bg-slate-300 transition-all flex items-center gap-1.5"><FileSearch size={14}/> Relatórios</button>
              <button onClick={() => openModal()} disabled={!canWriteFinance} className="px-5 py-1.5 bg-slate-900 text-white rounded-lg font-bold text-[10px] uppercase shadow-md hover:bg-slate-800 transition-all flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"><Plus size={14}/> Novo Lançamento</button>
            </>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 mb-4">
        {[
          { id: 'tesouraria', label: 'Tesouraria', icon: Wallet },
          { id: 'contas', label: 'Contas Bancárias', icon: CreditCard },
          { id: 'conciliacao', label: 'Conciliação Bancária', icon: Landmark }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <tab.icon size={16} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Conteúdo das Tabs */}
      {activeTab === 'tesouraria' && (
        <>
          <div className="grid grid-cols-3 gap-3">
            {[
              {l: 'Receita Realizada', v: totals.income, i: <TrendingUp/>, c: 'emerald'}, 
              {l: 'Despesa Liquidada', v: totals.expense, i: <ArrowDown/>, c: 'rose'}, 
              {l: 'Contas a Pagar', v: totals.payable, i: <History/>, c: 'amber'}
            ].map((s, i) => (
              <div key={i} className="bg-white p-3.5 rounded-xl border border-slate-100 flex items-center gap-3 shadow-sm hover:shadow-md transition-all">
                <div className={`p-2 rounded-lg bg-${s.c}-50 text-${s.c}-600`}>
                  {React.cloneElement(s.i as React.ReactElement<{ size?: number }>, {size: 16})}
                </div>
                <div>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">{s.l}</p>
                  <p className="text-lg font-black text-slate-900 mt-0.5">R$ {s.v.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-white p-1.5 rounded-xl border border-slate-100 shadow-sm overflow-hidden flex flex-col sm:flex-row gap-2">
            <div className="flex-1 relative">
              <Search className="absolute left-2.5 top-2 text-slate-400" size={14} />
              <input type="text" placeholder="Buscar por descrição, fornecedor ou documento..." className="w-full pl-8 pr-4 py-1.5 bg-transparent outline-none text-[12px] text-slate-900 font-medium" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto scrollbar-hide">
              <table className="w-full text-left min-w-[1000px]">
                <thead className="bg-slate-50/30 text-[10px] text-slate-400 font-black uppercase tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="px-4 py-3">Data / Competência</th>
                    <th className="px-4 py-3">Lançamento / Origem</th>
                    <th className="px-6 py-3">Natureza / Centro</th>
                    <th className="px-6 py-3 text-right">Valor Líquido</th>
                    <th className="px-6 py-3 text-center">Situação</th>
                    <th className="px-6 py-3 text-right">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50 text-[11px]">
                  {filtered.map(t => (
                    <tr key={t.id_transacao} className="hover:bg-slate-50/50 transition-all">
                      <td className="px-4 py-2.5">
                        <p className="font-bold text-slate-900 leading-none">{new Date(t.data_transacao).toLocaleDateString('pt-BR')}</p>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-1 tracking-tighter">ID: {t.id_transacao.slice(0,5).toUpperCase()}</p>
                      </td>
                      <td className="px-4 py-2.5">
                        <p className="font-bold text-slate-700 leading-none mb-0.5">{t.descricao}</p>
                        <p className="text-[9px] text-slate-400 font-medium uppercase">
                          {t.categoria === 'Dizimo' && t.id_membro ? (
                            <span className="flex items-center gap-1 text-indigo-600 font-black">
                              <User size={10}/> {members.find(m => m.id_membro === t.id_membro)?.nome || 'Membro'}
                            </span>
                          ) : (
                            t.id_unidade ? 'ADJPA Matriz' : 'Externo'
                          )}
                        </p>
                      </td>
                      <td className="px-6 py-2.5">
                        <p className="text-[9px] font-black text-indigo-600 uppercase tracking-tight leading-none">
                          {OPERATION_NATURES.find(n => n.id === t.natureza_operacao)?.name || 'OUTROS'}
                        </p>
                        <p className="text-[8px] text-slate-400 font-bold uppercase mt-0.5">
                          {COST_CENTERS.find(c => c.id === t.id_centro_custo)?.name || 'Geral'}
                        </p>
                      </td>
                      <td className={`px-6 py-2.5 text-right font-black ${t.tipo === 'ENTRADA' ? 'text-emerald-600' : 'text-rose-600'}`}>
                        R$ {t.valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="px-6 py-2.5 text-center">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${t.situacao === 'REALIZADO' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'}`}>
                          {t.situacao === 'REALIZADO' ? 'Liquidado' : 'Em Aberto'}
                        </span>
                      </td>
                      <td className="px-6 py-2.5 text-right text-slate-400">
                        <button onClick={() => openModal(t)} disabled={!canWriteFinance} className="hover:text-indigo-600 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"><Edit2 size={15}/></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {isModalOpen && (
            <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
              <div className="bg-white w-full max-w-4xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-4 border-b flex justify-between items-center bg-white">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-md"><DollarSign size={20}/></div>
                    <div>
                       <h2 className="font-black uppercase text-sm tracking-tight text-slate-900">{editingId ? 'Editar Lançamento' : 'Novo Lançamento Contábil'}</h2>
                       <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">PostgreSQL Cloud Sinc • ERP v5.0</p>
                    </div>
                  </div>
                  <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-all text-slate-400"><X size={20}/></button>
                </div>
                <div className="p-8 space-y-6 overflow-y-auto custom-scrollbar bg-slate-50/30">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                       <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Descrição do Lançamento / Histórico</label>
                       <input className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all" value={formData.descricao} onChange={e => setFormData({...formData, descricao: e.target.value})} placeholder="Ex: Dízimo do mês, Pagamento de Luz..." />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Valor Bruto (R$)</label>
                      <input type="number" className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-black text-xs text-indigo-700" value={formData.valor === 0 ? '' : formData.valor} onChange={e => setFormData({...formData, valor: e.target.value === '' ? 0 : Number(e.target.value)})} />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Data de Lançamento</label>
                      <input type="date" className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs" value={formData.data_transacao} onChange={e => setFormData({...formData, data_transacao: e.target.value})} />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Tipo de Fluxo</label>
                      <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={formData.tipo} onChange={e => setFormData({...formData, tipo: e.target.value as any})}>
                        <option value="ENTRADA">Receita / Arrecadação (+)</option>
                        <option value="SAIDA">Despesa / Pagamento (-)</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Categoria</label>
                      <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={formData.categoria} onChange={e => setFormData({...formData, categoria: e.target.value})} >
                        <option value="Dizimo">Dízimo</option>
                        <option value="OFFERING">Oferta</option>
                        <option value="CAMPAIGN">Campanha</option>
                        <option value="UTILITIES">Utilidades (Luz/Água)</option>
                        <option value="SALARY">Salários / RH</option>
                        <option value="MAINTENANCE">Manutenção</option>
                        <option value="OTHER">Outros</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Centro de Custo</label>
                      <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={formData.id_centro_custo} onChange={e => setFormData({...formData, id_centro_custo: e.target.value})} >
                        {COST_CENTERS.map(cc => <option key={cc.id} value={cc.id}>{cc.name}</option>)}
                      </select>
                    </div>
                  </div>

                  {/* OPÇÃO DE PARCELAMENTO (só para DESPESAS) */}
                  {formData.tipo === 'SAIDA' && (
                    <div className="p-6 bg-indigo-50 rounded-[2rem] border border-indigo-100 animate-in slide-in-from-top-2">
                      <div className="flex items-center gap-2 mb-4">
                        <CreditCard size={18} className="text-indigo-600" />
                        <label className="text-[10px] font-black uppercase text-indigo-700 flex items-center gap-2">
                          <input 
                            type="checkbox" 
                            checked={formData.parcelado} 
                            onChange={e => setFormData({...formData, parcelado: e.target.checked, total_parcelas: e.target.checked ? 2 : 1, jurosPercentual: 0} as any)}
                            className="w-4 h-4 accent-indigo-600"
                          />
                          Pagamento Parcelado
                        </label>
                      </div>
                      
                      {formData.parcelado && (
                        <div className="space-y-4 ml-6">
                          {/* Tipo de parcelamento */}
                          <div className="flex gap-3">
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input
                                type="radio"
                                name="tipoParcelamento"
                                value="sem_juros"
                                checked={!(formData as any).jurosPercentual}
                                onChange={() => setFormData({...formData, jurosPercentual: 0} as any)}
                                className="accent-indigo-600"
                              />
                              <span className="text-[10px] font-black text-indigo-700 uppercase">Sem Juros</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                              <input
                                type="radio"
                                name="tipoParcelamento"
                                value="com_juros"
                                checked={!!((formData as any).jurosPercentual > 0)}
                                onChange={() => setFormData({...formData, jurosPercentual: 1.99} as any)}
                                className="accent-rose-600"
                              />
                              <span className="text-[10px] font-black text-rose-700 uppercase">Com Juros</span>
                            </label>
                          </div>

                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="text-[9px] font-black uppercase text-indigo-600 block mb-1">Quantidade de Parcelas</label>
                              <select 
                                className="w-full px-3 py-2 bg-white border border-indigo-200 rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                                value={formData.total_parcelas}
                                onChange={e => setFormData({...formData, total_parcelas: Number(e.target.value)})}
                              >
                                {[2,3,4,5,6,7,8,9,10,11,12].map(n => <option key={n} value={n}>{n}x</option>)}
                              </select>
                            </div>

                            {/* Taxa de juros — só aparece se "Com Juros" */}
                            {(formData as any).jurosPercentual >= 0 && (formData as any).jurosPercentual !== undefined && (
                              <div>
                                <label className="text-[9px] font-black uppercase text-rose-600 block mb-1">Taxa de Juros (% a.m.)</label>
                                <input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  max="30"
                                  value={(formData as any).jurosPercentual || 0}
                                  onChange={e => setFormData({...formData, jurosPercentual: parseFloat(e.target.value) || 0} as any)}
                                  className="w-full px-3 py-2 bg-white border border-rose-200 rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-rose-400"
                                  placeholder="Ex: 1.99"
                                />
                              </div>
                            )}
                          </div>

                          {/* Resumo do parcelamento */}
                          {(() => {
                            const n = formData.total_parcelas || 2;
                            const total = formData.valor || 0;
                            const taxa = (formData as any).jurosPercentual || 0;
                            let valorParcela: number;
                            let totalComJuros: number;
                            if (taxa > 0) {
                              // Fórmula Price: PMT = PV * i / (1 - (1+i)^-n)
                              const i = taxa / 100;
                              valorParcela = total * i / (1 - Math.pow(1 + i, -n));
                              totalComJuros = valorParcela * n;
                            } else {
                              valorParcela = total / n;
                              totalComJuros = total;
                            }
                            return (
                              <div className={`p-4 rounded-xl border ${taxa > 0 ? 'bg-rose-50 border-rose-100' : 'bg-white border-indigo-100'}`}>
                                <div className="grid grid-cols-3 gap-3 text-center">
                                  <div>
                                    <p className="text-[8px] font-black uppercase text-slate-400">Valor da Parcela</p>
                                    <p className={`text-base font-black ${taxa > 0 ? 'text-rose-700' : 'text-indigo-700'}`}>R$ {valorParcela.toFixed(2)}</p>
                                  </div>
                                  <div>
                                    <p className="text-[8px] font-black uppercase text-slate-400">Total a Pagar</p>
                                    <p className={`text-base font-black ${taxa > 0 ? 'text-rose-700' : 'text-indigo-700'}`}>R$ {totalComJuros.toFixed(2)}</p>
                                  </div>
                                  {taxa > 0 && (
                                    <div>
                                      <p className="text-[8px] font-black uppercase text-slate-400">Juros Total</p>
                                      <p className="text-base font-black text-rose-600">R$ {(totalComJuros - total).toFixed(2)}</p>
                                    </div>
                                  )}
                                </div>
                                {taxa > 0 && (
                                  <p className="text-[8px] text-rose-500 text-center mt-2">
                                    {n}x de R$ {valorParcela.toFixed(2)} · Taxa {taxa}% a.m. · CET {(taxa * 12).toFixed(2)}% a.a.
                                  </p>
                                )}
                              </div>
                            );
                          })()}
                        </div>
                      )}
                      
                      <p className="text-[8px] font-medium text-indigo-600 mt-3 ml-6">
                        ℹ️ Serão geradas {formData.total_parcelas} contas a pagar com vencimento mensal.
                      </p>
                    </div>
                  )}

                  {formData.tipo === 'ENTRADA' && formData.categoria === 'Dizimo' && (
                    <div className="p-6 bg-emerald-50 rounded-[2rem] border border-emerald-100 animate-in slide-in-from-top-2">
                       <label className="text-[10px] font-black uppercase block mb-2 text-emerald-700 flex items-center gap-2"><User size={14}/> Selecionar Membro (Dizimista)</label>
                       <select 
                        className="w-full px-4 py-2 bg-white border border-emerald-200 rounded-2xl font-bold text-xs outline-none focus:ring-2 focus:ring-emerald-500" 
                        value={formData.id_membro || ''} 
                        onChange={e => setFormData({...formData, id_membro: e.target.value})}
                       >
                         <option value="">-- Selecione o Membro --</option>
                         {members.map(m => <option key={m.id_membro} value={m.id_membro}>{m.nome} ({m.situacao || 'Ativo'})</option>)}
                       </select>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Conta / Caixa Ativo</label>
                      <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={formData.id_conta} onChange={e => setFormData({...formData, id_conta: e.target.value})} >
                        {accounts.map(acc => <option key={acc.id_conta || acc.id} value={acc.id_conta || acc.id}>{acc.nome || acc.name}</option>)}
                      </select>
                    </div>
                    <div>
                       <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Natureza da Operação (FISCAL)</label>
                       <select className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs outline-none" value={formData.natureza_operacao} onChange={e => setFormData({...formData, natureza_operacao: e.target.value})} >
                        {OPERATION_NATURES.map(n => <option key={n.id} value={n.id}>{n.name}</option>)}
                       </select>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                     <div>
                       <label className="text-[10px] font-black uppercase block mb-1 text-slate-400">Fornecedor / Favorecido</label>
                       <input className="w-full px-4 py-2 bg-white border border-slate-200 rounded-2xl font-bold text-xs" value={formData.nome_fornecedor} onChange={e => setFormData({...formData, nome_fornecedor: e.target.value})} placeholder="Ex: CPFL, Sabesp, Nome Fornecedor..." />
                     </div>
                  </div>
                  <div className="p-6 bg-indigo-50/50 rounded-[2rem] border border-indigo-100 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-sm"><CreditCard size={18}/></div>
                      <div>
                        <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest leading-none">Meio de Movimentação</p>
                        <p className="text-xs font-bold text-slate-700 mt-1">Sincronização imediata via reconciliação bancária.</p>
                      </div>
                    </div>
                    <select className="px-4 py-1.5 bg-white border border-indigo-200 rounded-xl font-black text-[10px] uppercase outline-none shadow-sm" value={formData.forma_pagamento} onChange={e => setFormData({...formData, forma_pagamento: e.target.value as any})}>
                      <option value="PIX">PIX</option>
                      <option value="DINHEIRO">Dinheiro</option>
                      <option value="CARTAO_CREDITO">Cartão Corporativo</option>
                    </select>
                  </div>
                </div>
                <div className="p-4 bg-slate-50 border-t flex gap-3 shadow-inner">
                   <button onClick={() => setIsModalOpen(false)} disabled={isSaving} className="flex-1 py-2.5 font-bold uppercase text-[11px] bg-white border border-slate-200 rounded-2xl hover:bg-slate-100 transition-all disabled:opacity-50">Cancelar</button>
                   <button onClick={handleSave} disabled={isSaving || !canWriteFinance} className="flex-2 py-2.5 font-black uppercase text-[11px] bg-indigo-600 text-white rounded-2xl shadow-lg hover:bg-indigo-700 transition-all flex items-center justify-center gap-2 disabled:opacity-50">
                     {isSaving ? (
                       <>
                         <Loader2 size={16} className="animate-spin" />
                         Sincronizando...
                       </>
                     ) : (
                       <>
                         <Save size={16}/> Confirmar e Sincronizar ERP
                       </>
                     )}
                   </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Modal de Relatórios */}
      {isReportModalOpen && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md">
          <div className="bg-white w-full max-w-5xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-4 border-b flex justify-between items-center bg-white">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 text-white rounded-xl shadow-md"><FileSearch size={20}/></div>
                <div>
                   <h2 className="font-black uppercase text-sm tracking-tight text-slate-900">Relatórios Financeiros</h2>
                </div>
              </div>
              <button onClick={() => setIsReportModalOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-all text-slate-400"><X size={20}/></button>
            </div>
            <div className="p-8 overflow-y-auto custom-scrollbar bg-slate-50/30">
              <Relatorios transactions={transactions} members={members} />
            </div>
          </div>
        </div>
      )}

      {activeTab === 'contas' && (
        <ContasBancarias 
          currentIdUnidade={currentIdUnidade}
          onTransactionAdded={() => {
            // Recarregar transações se necessário
            console.log('Transação adicionada via ContasBancarias');
          }}
        />
      )}

      {activeTab === 'conciliacao' && (
        <ConciliacaoBancaria 
          currentIdUnidade={currentIdUnidade}
          user={user}
        />
      )}
    </div>
  );
};
