/**
 * ============================================================================
 * MEMBERSCONTROLLER.TS
 * ============================================================================
 *
 * O QUE ESTE ARQUIVO FAZ?
 * ------------------------
 * Controller que processa requisições relacionadas a members controller.
 *
 * ONDE É USADO?
 * -------------
 * Usado pelo servidor backend para processar requisições.
 *
 * COMO FUNCIONA?
 * --------------
 * Executa lógica de backend e responde a chamadas externas.
 */

import { Request, Response } from 'express';
import Database from '../database';
import { randomUUID } from 'crypto';

/**
 * BLOCO PRINCIPAL
 * ===============
 *
 * Define o bloco principal deste arquivo (members controller).
 */

const db = Database.getInstance();

// Migration automática de colunas para membros
export async function migrateMemberColumns(): Promise<void> {
  try {
    const columnsToRename = [
      { old: 'id_unidade', new: 'id_unidade' },
      { old: 'dados_perfil', new: 'dados_perfil' },
      { old: 'dizimista', new: 'dizimista' },
      { old: 'eh_ofertante_regular', new: 'ofertante_regular' },
    ];
    for (const { old, new: newCol } of columnsToRename) {
      try {
        await db.query(`ALTER TABLE membros RENAME COLUMN ${old} TO ${newCol}`);
        console.log(`✅ membros: ${old} → ${newCol}`);
      } catch (e: any) { /* ignora */ }
    }
  } catch (e) { /* ignora */ }
}

// Campos permitidos — correspondem exatamente às colunas da tabela members (schema real)
const ALLOWED_MEMBER_FIELDS = new Set([
  'id', 'id_unidade', 'matricula', 'nome', 'cpf', 'rg', 'email', 'telefone', 'whatsapp',
  'profissao', 'funcao', 'status', 'data_nascimento', 'sexo', 'estado_civil', 'nome_conjuge', 'data_casamento',
  'nome_pai', 'nome_mae', 'tipo_sanguineo', 'contato_emergencia', 'cep', 'logradouro',
  'numero', 'complemento', 'bairro', 'cidade', 'estado', 'data_conversao', 'local_conversao',
  'data_batismo', 'igreja_batismo', 'pastor_batizador', 'batismo_espirito_santo', 'data_membro',
  'igreja_origem', 'curso_discipulado', 'escola_biblica', 'ministerio_principal', 'funcao_ministerio',
  'outros_ministerios', 'cargo_eclesiastico', 'data_consagracao', 'dizimista', 'ofertante_regular',
  'participa_campanhas', 'banco', 'agencia_bancaria', 'conta_bancaria', 'chave_pix', 'observacoes',
  'necessidades_especiais', 'talentos', 'tags', 'familia_id', 'avatar', 'dados_perfil', 'celula', 'cell_group',
  'dons_espirituais', 'escolaridade', 'is_pcd', 'tipo_deficiencia', 'celular', 'lgpd_consent'
]);

const sanitizeMemberPayload = (
  payload: Record<string, any>,
  options?: { includeId?: boolean }
): Record<string, any> => {
  const result: Record<string, any> = {};
  
  // Mapeamento de campos do frontend para colunas do banco
  // Inclui compatibilidade com versões legadas (ex: celular vs whatsapp)
  const fieldMapping: Record<string, string> = {
    // Novos campos em PT (camelCase -> snake_case)
    'idUnidade': 'id_unidade',
    'dataNascimento': 'data_nascimento',
    'estadoCivil': 'estado_civil',
    'nomeConjuge': 'nome_conjuge',
    'dataCasamento': 'data_casamento',
    'nomePai': 'nome_pai',
    'nomeMae': 'nome_mae',
    'tipoSanguineo': 'tipo_sanguineo',
    'contatoEmergencia': 'contato_emergencia',
    'cep': 'cep',
    'logradouro': 'logradouro',
    'numero': 'numero',
    'complemento': 'complemento',
    'bairro': 'bairro',
    'cidade': 'cidade',
    'estado': 'estado',
    'dataConversao': 'data_conversao',
    'localConversao': 'local_conversao',
    'dataBatismo': 'data_batismo',
    'igrejaBatismo': 'igreja_batismo',
    'pastorBatizador': 'pastor_batizador',
    'batismoEspiritoSanto': 'batismo_espirito_santo',
    'dataMembro': 'data_membro',
    'igrejaOrigem': 'igreja_origem',
    'cursoDiscipulado': 'curso_discipulado',
    'escolaBiblica': 'escola_biblica',
    'ministerioPrincipal': 'ministerio_principal',
    'funcaoMinisterio': 'funcao_ministerio',
    'outrosMinisterios': 'outros_ministerios',
    'cargoEclesiastico': 'cargo_eclesiastico',
    'dataConsagracao': 'data_consagracao',
    'ehDizimista': 'dizimista',
    'ehOfertanteRegular': 'ofertante_regular',
    'participaCampanhas': 'participa_campanhas',
    'agenciaBancaria': 'agencia_bancaria',
    'contaBancaria': 'conta_bancaria',
    'chavePix': 'chave_pix',
    'necessidadesEspeciais': 'necessidades_especiais',
    'familiaId': 'familia_id',
    'cellGroup': 'cell_group',
    'celula': 'cell_group',
    'profissao': 'profissao',
    'funcao': 'funcao',
    'donsEspirituais': 'dons_espirituais',
    'escolaridade': 'escolaridade',
    'isPcd': 'is_pcd',
    'tipoDeficiencia': 'tipo_deficiencia',
    'celular': 'celular',
    'lgpdConsent': 'lgpd_consent',
    'consentimentoLgpd': 'lgpd_consent',
    
    // Legado (EN -> snake_case PT)
    'name': 'nome',
    'birthDate': 'data_nascimento',
    'maritalStatus': 'estado_civil',
    'spouseName': 'nome_conjuge',
    'marriageDate': 'data_casamento',
    'fatherName': 'nome_pai',
    'motherName': 'nome_mae',
    'bloodType': 'tipo_sanguineo',
    'emergencyContact': 'contato_emergencia',
    'zipCode': 'cep',
    'street': 'logradouro',
    'number': 'numero',
    'complement': 'complemento',
    'neighborhood': 'bairro',
    'city': 'cidade',
    'state': 'estado',
    'conversionDate': 'data_conversao',
    'conversionPlace': 'local_conversao',
    'baptismDate': 'data_batismo',
    'baptismChurch': 'igreja_batismo',
    'baptizingPastor': 'pastor_batizador',
    'holySpiritBaptism': 'batismo_espirito_santo',
    'membershipDate': 'data_membro',
    'churchOfOrigin': 'igreja_origem',
    'discipleshipCourse': 'curso_discipulado',
    'biblicalSchool': 'escola_biblica',
    'mainMinistry': 'ministerio_principal',
    'ministryRole': 'funcao_ministerio',
    'otherMinistries': 'outros_ministerios',
    'ecclesiasticalPosition': 'cargo_eclesiastico',
    'consecrationDate': 'data_consagracao',
    'isTithable': 'dizimista',
    'isRegularGiver': 'ofertante_regular',
    'participatesCampaigns': 'participa_campanhas',
    'bankAgency': 'agencia_bancaria',
    'bankAccount': 'conta_bancaria',
    'pixKey': 'chave_pix',
    'specialNeeds': 'necessidades_especiais',
    'familyId': 'familia_id',
    'phone': 'telefone',
    
    // Novas pontes de compatibilidade (EN snake_case -> PT snake_case)
    'father_name': 'nome_pai',
    'mother_name': 'nome_mae',
    'blood_type': 'tipo_sanguineo',
    'emergency_contact': 'contato_emergencia',
    'is_tithable': 'dizimista',
    'is_regular_giver': 'ofertante_regular',
    'participates_campaigns': 'participa_campanhas',
    'pix_key': 'chave_pix',
    'bank_agency': 'agencia_bancaria',
    'bank_account': 'conta_bancaria',
    'zip_code': 'cep',
    'conversion_date': 'data_conversao',
    'conversion_place': 'local_conversao',
    'baptism_date': 'data_batismo',
    'baptism_church': 'igreja_batismo',
    'baptizing_pastor': 'pastor_batizador',
    'membership_date': 'data_membro',
    'church_of_origin': 'igreja_origem',
    'discipleship_course': 'curso_discipulado',
    'biblical_school': 'escola_biblica',
    'main_ministry': 'ministerio_principal',
    'ministry_role': 'funcao_ministerio',
    'other_ministries': 'outros_ministerios',
    'ecclesiastical_position': 'cargo_eclesiastico',
    'consecration_date': 'data_consagracao',
    'special_needs': 'necessidades_especiais',
    'family_id': 'familia_id',
    'marriage_date': 'data_casamento',
    'spouse_name': 'nome_conjuge',
  };

  // Processar campos do endereço se existirem
  if (payload.address && typeof payload.address === 'object') {
    const addr = payload.address;
    if (addr.zipCode || addr.cep) result.cep = addr.zipCode || addr.cep;
    if (addr.street || addr.logradouro) result.logradouro = addr.street || addr.logradouro;
    if (addr.number || addr.numero) result.numero = addr.number || addr.numero;
    if (addr.complement || addr.complemento) result.complemento = addr.complement || addr.complemento;
    if (addr.neighborhood || addr.bairro) result.bairro = addr.neighborhood || addr.bairro;
    if (addr.city || addr.cidade) result.cidade = addr.city || addr.cidade;
    if (addr.state || addr.estado) result.estado = addr.state || addr.estado;
  }

  for (const [key, value] of Object.entries(payload || {})) {
if (key === 'id' && !options?.includeId) continue;
    if (key === 'address') continue; // Já processado acima
    if (key === 'dados_perfil') continue; // Já processado abaixo
    if (key === 'dados_perfil') continue; // Compatibilidade

    const targetKey = fieldMapping[key] || key;
    
    // Se o campo não está na lista de permitidos, adiciona ao dados_perfil
    if (!ALLOWED_MEMBER_FIELDS.has(targetKey)) {
      if (!result.dados_perfil) result.dados_perfil = {};
      // Se o campo for 'celular', garantimos que ele vá para dados_perfil
      // mesmo que o fieldMapping o tenha mantido como 'celular'
      result.dados_perfil[targetKey] = value;
      continue;
    }
    
    if (value === undefined) continue;
    
    // Proteção: não permitir que campos importantes sejam definidos como null se vierem vazios
    // Isso evita que matrículas existentes sejam perdidas
    const protectedFields = ['matricula'];
    if (protectedFields.includes(targetKey) && (value === '' || value === null)) {
      console.log(`⚠️ Campo protegido "${targetKey}" ignorado (valor vazio/null)`);
      continue;
    }
    
    result[targetKey] = value === '' ? null : value;
  }
  
  return result;
};

export class MembersController {
  async debugSanitize(req: Request, res: Response) {
    try {
      const testPayload = {
        name: 'Teste',
        whatsapp: '11987654321',
        cellGroup: 'A',
        dados_perfil: { lgpdConsent: {} }
      };
      
      console.log('\n\n=== DEBUG SANITIZE ===');
      console.log('Payload original:', JSON.stringify(testPayload, null, 2));
      
      const sanitized = sanitizeMemberPayload(testPayload);
      
      console.log('Payload sanitizado:', JSON.stringify(sanitized, null, 2));
      console.log('=== FIM DEBUG ===\n\n');
      
      res.json({
        original: testPayload,
        sanitized: sanitized,
        hasWhatsapp: 'whatsapp' in sanitized,
        hasCelular: 'celular' in sanitized,
        hasCell_group: 'cell_group' in sanitized
      });
    } catch (error) {
      res.status(500).json({ error: error });
    }
  }

  async getAll(req: Request, res: Response) {
    try {
      await migrateMemberColumns();
      
      const { idUnidade, search, status, page = '1', limit = '500' } = req.query;

      let query = `
        SELECT m.*, u.nome_unidade as unit_name
        FROM membros m
        JOIN units u ON m.id_unidade = u.id
        WHERE 1=1
      `;
      const params: any[] = [];
      let i = 1;

      if (idUnidade) { query += ` AND m.id_unidade = $${i++}`; params.push(idUnidade); }
      if (search) {
        query += ` AND (m.nome ILIKE $${i++} OR m.cpf ILIKE $${i++} OR m.email ILIKE $${i++})`;
        params.push(`%${search}%`, `%${search}%`, `%${search}%`);
      }
      if (status) { query += ` AND m.status = $${i++}`; params.push(status); }

      const offset = (parseInt(page as string) - 1) * parseInt(limit as string);
      query += ` ORDER BY m.matricula NULLS LAST LIMIT $${i++} OFFSET $${i++}`;
      params.push(parseInt(limit as string), offset);

      const result = await db.query(query, params);
      const mappedMembers = result.rows.map(m => ({
        id: m.id,
        id_unidade: m.id_unidade,
        matricula: m.matricula,
        nome: m.nome,
        cpf: m.cpf,
        rg: m.rg,
        email: m.email,
        telefone: m.telefone,
        whatsapp: m.whatsapp,
        profissao: m.profissao,
        funcao: m.funcao,
        status: m.status,
        nome_pai: m.nome_pai,
        nome_mae: m.nome_mae,
        tipo_sanguineo: m.tipo_sanguineo,
        contato_emergencia: m.contato_emergencia,
        cep: m.cep,
        data_conversao: m.data_conversao,
        local_conversao: m.local_conversao,
        data_batismo: m.data_batismo,
        igreja_batismo: m.igreja_batismo,
        pastor_batizador: m.pastor_batizador,
        batismo_espirito_santo: m.batismo_espirito_santo,
        data_membro: m.data_membro,
        igreja_origem: m.igreja_origem,
        curso_discipulado: m.curso_discipulado,
        escola_biblica: m.escola_biblica,
        ministerio_principal: m.ministerio_principal,
        funcao_ministerio: m.funcao_ministerio,
        outros_ministerios: m.outros_ministerios,
        cargo_eclesiastico: m.cargo_eclesiastico,
        data_consagracao: m.data_consagracao,
        dizimista: m.dizimista,
        eh_ofertante_regular: m.ofertante_regular ?? m.eh_ofertante_regular,
        participa_campanhas: m.participa_campanhas,
        banco: m.banco,
        agencia_bancaria: m.agencia_bancaria,
        conta_bancaria: m.conta_bancaria,
        chave_pix: m.chave_pix,
        necessidades_especiais: m.necessidades_especiais,
        familia_id: m.familia_id,
        cell_group: m.cell_group || m.celula,
        data_nascimento: m.data_nascimento,
        sexo: m.sexo,
        celular: m.celular,
        escolaridade: m.escolaridade,
        dons_espirituais: m.dons_espirituais,
        is_pcd: m.is_pcd,
        tipo_deficiencia: m.tipo_deficiencia,
        estado_civil: m.estado_civil,
        nome_conjuge: m.nome_conjuge,
        data_casamento: m.data_casamento,
        talentos: m.talentos,
        tags: m.tags,
        logradouro: m.logradouro,
        numero: m.numero,
        complemento: m.complemento,
        bairro: m.bairro,
        cidade: m.cidade,
        estado: m.estado,
        observacoes: m.observacoes,
        dados_perfil: m.dados_perfil,
        avatar: m.avatar,
        criado: m.criado,
        atualizado: m.atualizado,
        unit_name: m.unit_name
      }));

      // Contagem total
      let countQuery = `SELECT COUNT(*) as total FROM membros m WHERE 1=1`;
      const countParams: any[] = [];
      let ci = 1;
      if (idUnidade) { countQuery += ` AND m.id_unidade = $${ci++}`; countParams.push(idUnidade); }
      if (search) {
        countQuery += ` AND (m.nome ILIKE $${ci++} OR m.cpf ILIKE $${ci++} OR m.email ILIKE $${ci++})`;
        countParams.push(`%${search}%`, `%${search}%`, `%${search}%`);
      }
      if (status) { countQuery += ` AND m.status = $${ci++}`; countParams.push(status); }

      const countResult = await db.query(countQuery, countParams);
      const total = parseInt(countResult.rows[0].total);

      res.json({
        members: mappedMembers,
        pagination: {
          page: parseInt(page as string),
          limit: parseInt(limit as string),
          total,
          pages: Math.ceil(total / parseInt(limit as string))
        }
      });
    } catch (error) {
      console.error('Erro ao buscar membros:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async getById(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const result = await db.query(
        `SELECT m.*, u.nome_unidade as unit_name FROM membros m JOIN units u ON m.id_unidade = u.id WHERE m.id = $1`,
        [id]
      );
      if (result.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }
      const dependentsResult = await db.query(
        'SELECT * FROM dependents WHERE id_membro = $1 ORDER BY nome', [id]
      );
      const contributionsResult = await db.query(
        'SELECT * FROM member_contributions WHERE id_membro = $1 ORDER BY data_contribuicao DESC', [id]
      );
      const member = result.rows[0];
      // Compatibilidade: whatsapp já é o nome correto da coluna
      member.whatsapp = member.whatsapp;
      member.dependents = dependentsResult.rows;
      member.contributions = contributionsResult.rows;
      res.json(member);
    } catch (error) {
      console.error('Erro ao buscar membro:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async create(req: Request, res: Response) {
    try {
      const { lgpdConsent, ...restOfBody } = req.body;
      const memberData: Record<string, any> = {
        id: randomUUID(),
        ...sanitizeMemberPayload(restOfBody, { includeId: false })
      };

      if (lgpdConsent) {
        memberData.dados_perfil = { ...(memberData.dados_perfil || memberData.dados_perfil || {}), lgpdConsent };
      }

      if (!memberData.nome || !memberData.cpf || !memberData.id_unidade) {
        return res.status(400).json({ error: { message: 'Nome, CPF e unidade são obrigatórios', status: 400 } });
      }

      const existingCpf = await db.query('SELECT id FROM membros WHERE cpf = $1', [memberData.cpf]);
      if (existingCpf.rows.length > 0) {
        return res.status(409).json({ error: { message: 'CPF já cadastrado', status: 409 } });
      }

      const unitExists = await db.query('SELECT id FROM units WHERE id = $1', [memberData.id_unidade]);
      if (unitExists.rows.length === 0) {
        return res.status(400).json({ error: { message: 'Unidade não encontrada', status: 400 } });
      }

      const fields = Object.keys(memberData);
      const values = Object.values(memberData);
      
      const placeholders = fields.map((_, idx) => `$${idx + 1}`).join(', ');

      const result = await db.query(
        `INSERT INTO membros (${fields.join(', ')}, criado, atualizado)
         VALUES (${placeholders}, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
         RETURNING *`,
        values
      );
      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao criar membro:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async update(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const { lgpdConsent, ...restOfBody } = req.body;

      console.log('🔍 UPDATE - Body recebido:', JSON.stringify(restOfBody, null, 2));
      console.log('🔍 UPDATE - WhatsApp no body:', restOfBody.whatsapp);
      console.log('🔍 UPDATE - Celular no body:', restOfBody.celular);
      console.log('🔍 UPDATE - Matricula no body:', restOfBody.matricula);

      const updateData = sanitizeMemberPayload(restOfBody, { includeId: false });

      console.log('🔍 UPDATE - Dados após sanitize:', JSON.stringify(updateData, null, 2));
      console.log('🔍 UPDATE - WhatsApp em updateData:', updateData.whatsapp);
      console.log('🔍 UPDATE - Matricula em updateData:', updateData.matricula);

      // Obter o registro atual para mesclar dados
      const currentResult = await db.query('SELECT dados_perfil FROM membros WHERE id = $1', [id]);
      if (currentResult.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }

      // Sempre mesclar dados_perfil preservando dados existentes
      const currentProfileData = currentResult.rows[0]?.dados_perfil || currentResult.rows[0]?.dados_perfil || {};
      updateData.dados_perfil = {
        ...currentProfileData,
        ...(updateData.dados_perfil || updateData.dados_perfil || {}),
        ...(lgpdConsent ? { lgpdConsent: { ...(currentProfileData.lgpdConsent || {}), ...lgpdConsent } } : {})
      };

      if (updateData.cpf) {
        const existingCpf = await db.query('SELECT id FROM membros WHERE cpf = $1 AND id != $2', [updateData.cpf, id]);
        if (existingCpf.rows.length > 0) {
          return res.status(409).json({ error: { message: 'CPF já cadastrado', status: 409 } });
        }
      }

      const fields = Object.keys(updateData);
      if (fields.length === 0 && !lgpdConsent) { // Se só lgpdConsent mudou, ainda permite
        return res.status(400).json({ error: { message: 'Nenhum campo válido para atualização', status: 400 } });
      }

      console.log('🔍 UPDATE - Campos que serão atualizados:', fields);
      console.log('🔍 UPDATE - Inclui matricula?', fields.includes('matricula'));

      const values = Object.values(updateData);
      
      const setClause = fields.map((f, idx) => `${f} = $${idx + 1}`).join(', ');
      const finalSetClause = `${setClause}${setClause ? ', ' : ''}atualizado = CURRENT_TIMESTAMP`;

      const result = await db.query(
        `UPDATE membros SET ${finalSetClause} WHERE id = $${fields.length + 1} RETURNING *`,
        [...values, id]
      );

      if (result.rowCount === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }

      console.log('✅ UPDATE concluído. Matrícula no membro retornado:', result.rows[0].matricula);

      res.json(result.rows[0]);
    } catch (error: any) {
      console.error('❌ Erro ao atualizar membro:', error?.message || error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async delete(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const existsResult = await db.query('SELECT id FROM membros WHERE id = $1', [id]);
      if (existsResult.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }
      await db.query('UPDATE membros SET status = $1, atualizado = CURRENT_TIMESTAMP WHERE id = $2', ['INACTIVE', id]);
      res.json({ message: 'Membro removido com sucesso' });
    } catch (error) {
      console.error('Erro ao remover membro:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async addDependent(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const d = req.body;
      const existsResult = await db.query('SELECT id FROM membros WHERE id = $1', [id]);
      if (existsResult.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }
      const result = await db.query(
        `INSERT INTO dependents (id_membro, nome, data_nascimento, parentesco, cpf, criado)
         VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP) RETURNING *`,
        [id, d.nome || d.name, d.data_nascimento || d.birth_date, d.parentesco || d.relationship, d.cpf]
      );
      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao adicionar dependente:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }

  async addContribution(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const c = req.body;
      const existsResult = await db.query('SELECT id FROM membros WHERE id = $1', [id]);
      if (existsResult.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Membro não encontrado', status: 404 } });
      }
      const result = await db.query(
        `INSERT INTO member_contributions (id_membro, valor, data_contribuicao, tipo, descricao, criado)
         VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP) RETURNING *`,
        [id, c.valor || c.value, c.data_contribuicao || c.contribution_date, c.tipo || c.type, c.descricao || c.description]
      );
      res.status(201).json(result.rows[0]);
    } catch (error) {
      console.error('Erro ao adicionar contribuição:', error);
      res.status(500).json({ error: { message: 'Erro interno do servidor', status: 500 } });
    }
  }
}
